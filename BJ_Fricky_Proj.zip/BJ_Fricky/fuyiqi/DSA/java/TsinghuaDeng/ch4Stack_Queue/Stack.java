package TsinghuaDeng.ch4Stack_Queue;

import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

public class Stack {




    public void ten2two(int num){
        List<Integer> stack = new ArrayList<>();
        while (num!=0){
            int digit = num%2;
            stack.add(digit);
            num /=2;
        }

        for(int i = stack.size()-1;i>=0; i--){
            System.out.println(stack.get(i));
        }

    }

    @Test
    public void test1(){
        ten2two(10);
    }


    /**
     * @Description: 括号匹配
     * 使用计数器适合单个符号
     * **/
    public boolean braceMatch(){


        return false;
    }












}
