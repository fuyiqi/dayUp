package TsinghuaDeng.ch2Vector;

import org.testng.annotations.Test;


/**
 * 1.起泡排序->减而治之
 * 2.归并排序->分而治之
 * **/


public class Sort {

    /**
     *  @Description 交换数组中两个元素位置的值
     **/
    public static void swap(int[] data, int pos_a, int pos_b) {
        int temp;
        temp = data[pos_a];
        data[pos_a] = data[pos_b];
        data[pos_b] = temp;
    }

    /**
     * @Description 起泡排非逆序A
     * 将向量a[0,n)划分为有序部分a[0,k)和无序部分a[k,n)，假设有序部分在末尾且有序是从小到大的排列，
     * 通过第i次的从左到右的扫描，将两两之间存在的逆序对互相调换位置
     * 来保证有序的部分和无序的部分的此消彼长
     * 以此来达到第i大的元素在第n-i的位置上的目的
     */
    public void bubble_A(int[] a){
        for(int i=0;i<a.length;i++){
            //第i次的从左到右的扫描
            for(int j= i+1;j<a.length;j++){
                if(a[j]<a[i]){//出现逆序
                    swap(a,i,j);
                }
            }
        }
    }



    /**
     * @Description 起泡排非逆序B
     * 明确末尾是有序的，从左向右扫描，在将第i个大的数放在n-i的时候，
     *  待比较的元素a[i]和a[n-i]是逆序对的时候 则全局未排序完还需继续扫描
     *  否则全局排序结束
     */
    public void bubble_B(int[] a){
        int low = 0;
        int high = a.length-1;
        while (bubble_b(a,low,high--));
    }

    /**
     * @Description 单趟的起泡排序
     * 在单次扫描的过程中，报告当前是否有逆序对，
     *  ->有,则决定下一次要扫描
     *  ->没有,则跳过下一次的扫描
     */
    public boolean bubble_b(int[]a, int pos_low, int pos_high){
        boolean isSorted = true;//全局排序标志
        while(++pos_low<pos_high){//从左向右检查相邻的两两元素
            if(a[pos_low]<a[pos_low-1]){//出现逆序对
                //System.out.println(a[pos_low]+","+a[pos_high]);
                swap(a,pos_low-1,pos_low);
                isSorted = false;
            }
        }
        return isSorted;
    }



    @Test
    public void test(){
        int[] a = {1,9,4,5,3};
        bubble_A(a);
        for (int e:a){
            System.out.println(e);
        }
    }

    /**
     * @Description 起泡排非逆序C
     * 缩短查找区间
     */
    public void bubble_C(int[] a){
        int low = 0;
        int high = a.length-1;
        while (low<(high = bubble_c(a,low,high)));
    }

    public int bubble_c(int[] a,int pos_low, int pos_high){
        int right = pos_low;//下一次查找区间的右边界
        while(++pos_low<pos_high){//从左向右检查两两元素
            if(a[pos_low]<a[pos_low-1]){//出现逆序对
                right = pos_low; //逆序对的右边界
                swap(a,pos_low-1,pos_low);
            }
        }
        return right;

    }

    /**
     * @Description 二路归并排序
     */
    public void biMergesort(int[] a,int pos_low, int pos_high){
        if(a.length==0||null == a){
            return;
        }
        int pos_mid = (pos_low+pos_high)>>1;
        biMergesort(a,pos_low,pos_mid);
        biMergesort(a,pos_mid+1,pos_high);
        merge(a,pos_low,pos_mid,pos_high);
    }

    public void merge(int[] a,int left,int mid,int right){

        int[] tempArr = new int[a.length];
        int leftStart = left;
        int rightStart = mid+1;
        int tempIndex = left;

        while(leftStart <= mid && rightStart <= right) {
            if(a[leftStart] < a[rightStart]) {
                tempArr[tempIndex++] = a[leftStart++];
            } else {
                tempArr[tempIndex++] = a[rightStart++];
            }
        }

        while(leftStart <= mid) {
            tempArr[tempIndex++] = a[leftStart++];
        }

        while(rightStart <= right) {
            tempArr[tempIndex++] = a[rightStart++];
        }

        while(left <= right) {
            a[left] = tempArr[left++];
        }





    }



    @Test
    public void t(){

        int[] a = {5,8,13,22};
        int[] b = {2,4,10,29};
        for(int e:mergeArr(a,b)){
            System.out.println(e);
        }

    }
    //合并两个非逆序数组，使其还是非逆序
    public int[] mergeArr(int[]a, int[]b){
        int a_idx = 0, b_idx = 0, tmp_idx=0;
        int[] tmp = new int[a.length+b.length];
        while (a_idx<a.length && b_idx<b.length){//每次都取最小的
            if(a[a_idx]>b[b_idx]){
                tmp[tmp_idx++] = b[b_idx++];
                //System.out.println(b[b_idx++]);//取出元素，指针后移
            }else {
                tmp[tmp_idx++] = a[a_idx++];
                //System.out.println(a[a_idx++]);//取出元素，指针后移
            }

        }

        //找到还没指到尾的指针
        if(a_idx>b_idx){
            while (b_idx<b.length){
                tmp[tmp_idx++] = b[b_idx++];
                //System.out.println(b[b_idx++]);//取出元素，指针后移
            }

        }else{
            while (a_idx<a.length){
                tmp[tmp_idx++] = a[a_idx++];
                //System.out.println(a[a_idx++]);//取出元素，指针后移
            }

        }
        return tmp;
    }



}
