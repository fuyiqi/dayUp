package TsinghuaDeng.ch2Vector;

import org.testng.annotations.Test;

public class binarySearch {

    @Test
    public void test1(){
        int[] a ={1,2,3,4,5,6};
        System.out.println(binarySearch1(a,0,5,3));

    }


    /**
     * 《二分查找，返回第一次匹配的位置》
     *  对于不递减的单调有序序列A[0,n)(0<=low<=high<n),找到元素target函数binarySearch(A[0,n),low,high,target)包含以下几种情况
     *  1. low < high
     *      mid = (low+high)/2
     *      1.1 A[mid] = = target,则返回mid
     *      1.2 target < A[mid],则在A[low,mid)区间查找
     *      1.3 A[mid] < target,则在A(mid,high]区间查找
     *  2. low >=high
     *      未找到
     * **/
    public int binarySearch1(int[] a, int low, int high,int target){//非递归版
        while (low<high){
            int mid = (low+high)>>1;
            if(a[mid]==target){
                return mid;
            }
            else {
                if (target < a[mid]) {
                    high = mid-1;
                }
                else if (a[mid] < target) {
                    low = mid+1;
                }
            }
        }
        return -1;
    }

    /**
     * 《二分查找，返回所有匹配的位置》
     * 还是在不递减的单调前提下
     * 1.未找到的逻辑不变
     * 2.第一次找到的时，不立刻退出，往左和往右都匹配一下，出现不匹配的时候才退出
     * **/
    public void biSearchAll(){//TODO

    }

    /**黄金分割的类二分查找
     * **/
    public int fibonacciSearch(){//TODO
        return 0;
    }

    /**
     * 插值查找（类二分查找）
     *在单调不递减且分布均匀的有序序列中
     *
     *axis= （low+high）/ 2, 即 axis = low + 1/2 * (high - low);
     *axis = low + (key - a[low]) / (a[high] - a[low]) * (high - low)
     *
     * **/
    public int interpolationSearch(){



        return -1;
    }

    @Test
    public void test3(){
       int[] a = {5,10,12,14,26,31,38,39,42,46,49,51,54,59,72,79,82,86,92};
    }






























}
