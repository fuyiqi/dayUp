package TsinghuaDeng.ch1Concept;

import org.testng.annotations.Test;

public class App {

    /**交换数组中两个元素位置的值**/
    public static void swap(int[] data, int a, int b) {
        int temp;
        temp = data[a];
        data[a] = data[b];
        data[b] = temp;

    }

    /**线性反转数组**/
    public void reverse1(int[] a,int low,int high){
        while (low<high){
            swap(a,low++,high--);
        }
    }

    @Test
    public void test1(){
        int[] a = {1,2,3,4,5,6};
        reverse2(a,0,a.length-1);
        for(int e:a){
            System.out.println(e);
        }
    }

    /**递归反转数组**/
    public void reverse2(int[] a,int low,int high){
        if(low<high){//<一般的情况>
            swap(a,low,high);
            reverse2(a,low+1,high-1);
        }else {//递归基<平凡的情况>
            if(low==high){
               return;
            }
            if(low>high){
                return;
            }
        }

    }

    /**减而治之的求和**/
    public int sum1(int[] a,int low,int high){
        int res = 0;
        while (low<=high){
            res+=a[high--];
        }
        return res;
    }

    /**减而治之的递归求和**/
    public int sum2(int[] a,int low,int high){
        int len = high-low+1;
        if(len<=0){//递归基<平凡的情况>
            return 0;
        }else {//<一般的情况>
            return sum2(a,low,high-1)+a[high];
        }
    }


    /**分而治之<二分>的递归求和**/
    public int sum3(int[] a,int low,int high){
        if(low==high){//递归基<平凡的情况>
            return a[low];
        }else {//<一般的情况>
            int mid = (low+high)>>1;
            return sum3(a,low,mid)+sum3(a,mid+1,high);
        }

    }




    @Test
    public void test2(){
        int[] a = {1,2,3,4,5,6,7};
        System.out.println(sum3(a,0,6));
    }


    /**
     * 《最长公共子序列（LongesCommonSubSeq）的长度》
     * 对于序列A[0,n]和B[0,m],LCS(A,B)符合以下3种情况
     * <递归基，即平凡的情况>
     * 1. 若n=-1或m=-1则LCS(A[0,n],B[0,m])=0(取空序列"")
     * <一般的情况>
     * 2.1 若A[n]= = B[m] (A序列最后一个字符和B序列最后一个字符相等) 则LCS(A[0,n],B[0,m])=LCS(A[0,n),B[0,m))+1
     * 2.2 若A[n]! = B[m] 则LCS(A[0,n],B[0,m]) = max(
     *                                              LCS(A[0,n],B[0,m)),
     *                                              LCS(A[0,n),B[0,m])
     *                                              )
     * **/

    public int LCS(String a,String b){
        int high_a = a.length()-1;
        int high_b = b.length()-1;
        if(high_a==-1 || high_b==-1){//递归基，即平凡的情况<1>
            return 0;
        }else {//一般的情况
            if(a.charAt(high_a)==b.charAt(high_b)){//<2.1>

                return LCS(a.substring(0,high_a),b.substring(0,high_b))+1;
            }else{//<2.2>
                return Math.max(
                        LCS(a.substring(0,high_a+1),b.substring(0,high_b)),
                        LCS(a.substring(0,high_a),b.substring(0,high_b+1))
                );
            }
        }

    }

    @Test
    public void test3(){
        String a = "cytaug";
        String b = "1yahug2ko";
        System.out.println(LCS(a,b));
    }



































































































}
