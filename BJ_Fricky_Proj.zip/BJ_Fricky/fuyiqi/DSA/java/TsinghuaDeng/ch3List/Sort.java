package TsinghuaDeng.ch3List;

import org.testng.annotations.Test;

public class Sort {

    /**
     *  @Description 交换数组中两个元素位置的值
     **/
    public static void swap(int[] data, int pos_a, int pos_b) {
        int temp;
        temp = data[pos_a];
        data[pos_a] = data[pos_b];
        data[pos_b] = temp;
    }

    @Test
    public void test(){
        int[] a = {1,9,4,5,3};
        selectionSort(a);
        for(int e:a){
            System.out.println(e);
        }
    }

    /**
     * @Description: 选择排非逆序，在第i次排序的过程中，在无序的部分[0,head)找出第i大的直接放置有序的部[head,tail)合适的位置
     * (bubbleSort也是一种selectionSort，区别就在于bubbleSort是不断梳理两两之间的逆序对来将全局顺序确定)
     * **/
    public void selectionSort(int[] a){
        int head=0, tail=a.length;
        while(head<tail){//
            int curMax= a[--tail];
            for(int i = head;i<tail;i++){
                if(a[i]>curMax){//出现逆序，交换
                    curMax = a[i];
                    swap(a,i,tail);
                }
            }
        }
    }


    /**
     * @Description: 直接插入排非逆序。
     * 对于数组A[0,n)，在排序的过程中总是可以数组A[0,n)将其划分为有序A[0,r)，无序A[r,n)两个部分
     * 在第r次迭代中，需要找到A[r]在A[0,r)中的位置，总会有A[r]<=A[i+1]使其有序部分变成A[0,r+1)
     * **/
    public void insertionSort(int[] a){
        for (int i = 1; i < a.length; i++)
        {
            int pos = i -1 ;    //有序序列的最后一个元素位置
            int cur = a[i];    //待排序元素的值
            while ( pos >= 0 && a[pos] > cur)//找到不再是逆序对的情况
            {
                a[pos + 1] = a[pos];
                pos--;
            }
            a[pos + 1] = cur;    //将待排序元素插入数组中
        }

    }






}
