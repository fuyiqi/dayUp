import org.testng.Assert;
import org.testng.annotations.Test;


/*******leetcode*********/
public class Solution {

    /**
     * @Description: 724. 寻找数组的中心索引
     * **/
    public int pivotIndex(int[] nums) {
        int total = getSum(nums,0,nums.length);
        int sum = 0;
        for(int i=0;i<nums.length;i++){
            if(2*sum+nums[i]==total){
                return i;
            }
            sum+=nums[i];
        }
        return -1;
    }

    /**
     * @Description: 对a[left,high)求和
     * **/
    private int getSum(int[]a,int left,int high){
        int sum = 0;
        while (left<high){
            sum+=a[left++];
        }

        return sum;
    }

    @Test
    public void test724(){
        int[] a1 = {1, 7, 3, 6, 5, 6};
        int[] a2 = {1, 2, 3};
        int[] a3 ={-1,-1,-1,-1,-1,-1};
        int[] a4 = {-1,-1,-1,-1,-1,0};
        System.out.println("actual="+pivotIndex(a1)+",expected="+3);
        System.out.println("actual="+pivotIndex(a2)+",expected="+-1);
        System.out.println("actual="+pivotIndex(a3)+",expected="+-1);
        System.out.println("actual="+pivotIndex(a4)+",expected="+2);

    }

    /**
     * @Description: 1. 两数之和
     * **/
    public void twoSum(int[] nums, int target) {
        for(int i = 0;i < nums.length;i++){
            int suppose_one = target-nums[i];
            for (int j= i+1;j<nums.length;j++){
                if(suppose_one==nums[j]){
                    System.out.println(nums[i]+"+"+nums[j]+"="+target+",i="+i+",j="+j);
                }
            }
        }

    }

    @Test
    public void test1(){
      int[] a1 = {2,7,11,15};
      int[] a2 = {3,2,4};
      int[] a3 = {3,3};

      twoSum(a1,9);
      twoSum(a2,6);
      twoSum(a3,6);

    }













}
