package utils;

import org.testng.annotations.Test;

import java.io.*;

public class FileHelper {

    public String getFile(String path){
        InputStream in  = this.getClass().getResourceAsStream(path);
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        String s;
        StringBuffer sb = new StringBuffer();
        try{
            while((s=reader.readLine()) != null){
            sb.append(s.trim()+"\n");
            }
        }catch (Exception e){}
        finally {
            try {
                reader.close();
            }catch (Exception e){}
        }
        //System.out.println(sb.toString());
        return sb.toString();
    }

    @Test
    public void test1(){
        getFile("/input/hello");
    }

    public  String getFileContent(String filePath) throws IOException {
        StringBuffer sb = new StringBuffer();
        File file = new File(filePath);
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String tempStr;
        while ((tempStr = reader.readLine()) != null){
            sb.append(tempStr+"\n");
        }
        reader.close();
        //System.out.println(sb.toString());
        return sb.toString();
    }
    @Test
    public void test2(){
        try {
            getFileContent("target/classes/input/hello");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
