package July.ch1._6;

import org.testng.annotations.Test;

public class Solution {

    public int LongestPalindrome(String str){
        int str_len = str.length();
        if(str_len%2==0){
            int global_max = 0;
            for(int center=0;center<str_len;center++){
                int partial_max = 0;
                for(int r=0;(center>=r)&&(center+r+1)<str_len;r++){
                    boolean isEqual = str.charAt(center-r) == str.charAt(center+r+1);
                    if(!isEqual){
                        break;
                    }
                    partial_max = r*2+2;
                    if(partial_max>global_max){
                        global_max = partial_max;
                    }
                }
            }
            System.out.println(global_max);
            return global_max;
        }else {
            int global_max = 0;
            for(int center=0;center<str_len;center++){
                int partial_max = 0;
                for(int r=0;(center>r)&&(center+r)<str_len;r++){
                    boolean isEqual = str.charAt(center-r) == str.charAt(center+r);
                    if(!isEqual){
                        break;
                    }
                    partial_max = r*2+1;
                    if(partial_max>global_max){
                        global_max = partial_max;
                    }
                }
            }
            System.out.println(global_max);
            return global_max;
        }

    }




    public boolean isPalindrome(String str){
        boolean flag = true;
        int str_len = str.length();
        if(str_len%2==0){
            int left = 0; int right = str_len-1;
            while (left<right){
                boolean isEuqal = str.charAt(left) == str.charAt(right);
                if(isEuqal){
                    ++left;--right;
                }else {
                    return false;
                }
            }
        }else {
            int mid = str_len/2;
            for (int i=0; i<=mid; i++){
                boolean isEuqal = str.charAt(mid-i) == str.charAt(mid+i);
                if(!isEuqal){
                    return false;
                }
            }
        }
        return flag;
    }

    public void findAllPalindrome(String str){
        int str_len = str.length();
        for(int p = 0;p<str_len;p++){
            int maxR = str_len-p;
            for(int r=0;r<maxR;r++){
                String tmp = str.substring(p,p+r+1);
                if(isPalindrome(tmp)){
                    System.out.println(tmp);
                }
            }
        }



    }






    @Test
    public void test(){
        String str1 = "1221";
        int res = LongestPalindrome(str1);
        //findAllPalindrome(str1);
    }

































}
