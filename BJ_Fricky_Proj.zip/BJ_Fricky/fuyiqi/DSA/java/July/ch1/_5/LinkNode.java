package July.ch1._5;

public class LinkNode {

    public int value ;
    public LinkNode next = null;

    public LinkNode(int value){
        this.value = value;
    }

    public LinkNode (){
        this.value = -1;
    }

    public String toString(){
        return String.valueOf(this.value);
    }


}
