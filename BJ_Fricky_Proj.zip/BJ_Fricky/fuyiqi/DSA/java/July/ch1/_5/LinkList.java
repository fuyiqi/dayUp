package July.ch1._5;

import org.testng.annotations.Test;

public class LinkList {

    /**
     * 获取带头节点的单链表长度
     * @param node
     * @return
     */
    public int getLength(LinkNode node){
       int length = 0;
        //LinkNode p = node.next;//带头指针
        LinkNode p = node;
        while(p!=null){
            length++;
            p = p.next;
        }
        return length;
    }

    /**
     * 头插法  带头指针
     * @return
     */
    public LinkNode headInsert(int[] nums){
        LinkNode node = new LinkNode();
        for(int e:nums){
            //System.out.println(e);
            LinkNode insert = new LinkNode(e);
            LinkNode cur = node;
            if(cur.next == null){
                cur.next = insert;
            }else {
                LinkNode uninsertNext = cur.next;
                cur.next = insert;
                insert.next = uninsertNext;
            }
        }
        return node;
    }

    /**
     * 带头节点的尾插法
     * @param nums
     * @return
     */
    public LinkNode tailInsert(int[] nums){
        LinkNode node = new LinkNode();
        for(int e:nums){
            LinkNode insert = new LinkNode(e);
            LinkNode cur = node;
            if(cur.next==null){
               cur.next = insert;
            }else {
                while (cur.next!=null){
                    cur = cur.next;
                }
                cur.next = insert;
            }
        }
        return node;
    }



    /**
     * 遍历带头节点的链表
     * @param node
     */
    public void travel(LinkNode node){
        if(node.next == null){
            return;
        }else {
            //LinkNode cur = node.next;//带头指针
            LinkNode cur = node;
            while (cur != null){
                System.out.println(cur.value);
                cur = cur.next;
            }

        }
    }

    /**
     * 原地逆置带头节点的单链表
     * @param node
     * @return
     */
    public LinkNode reverse(LinkNode node){
        LinkNode pre = null;
        LinkNode now = node;
        LinkNode next = node.next;
        while (next!=null){
            now.next = pre;
            LinkNode tmp = now ;
            now = next;
            pre = tmp;
            next= next.next;
        }
        //补齐
        LinkNode tmp = new LinkNode();
        now.next = pre;
        tmp.next = now;

        return tmp;
    }

    /**
     * 移除头结点
     * @param node
     * @return
     */
    public LinkNode removeHead(LinkNode node){
        return node.next;
    }


    @Test
    public void test(){
        int[] nums = {0,1,2,3,4,5};
        LinkNode res1 = headInsert(nums);
        //travel(res1);
        LinkNode res2 = tailInsert(nums);
        //travel(res2);
        LinkNode unhead = removeHead(res2);
        LinkNode res = reverse(unhead);
        //travel(res);

    }

    public LinkNode mergeTwoLists(LinkNode l1, LinkNode l2) {
        int l1_len = getLength(l1);
        int l2_len = getLength(l2);
        LinkNode longer,shorter;
        if(l1_len>l2_len){
           longer = l1;
           shorter = l2;
        }else {
            longer = l2;
            shorter = l1;
        }

        


        return null;
    }

    @Test
    public void test_mergeTwoLists(){

        int[] nums1 = {1,2,4};
        int[] nums2 = {1,3,4};
        int[] res1={1,1,2,3,4,4};
        LinkNode n1 = tailInsert(nums1);
        LinkNode n2 = tailInsert(nums2);
        LinkNode r1 = tailInsert(res1);


        mergeTwoLists(n1,n2);

    }






}
