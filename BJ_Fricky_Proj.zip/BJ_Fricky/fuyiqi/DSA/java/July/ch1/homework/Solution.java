package July.ch1.homework;

import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class Solution {

    public void firstOnceCharacter(String str){
        Map<String,Integer> wordFreq = new HashMap<>();
        int str_len = str.length();
        for(int i = 0; i<str_len; i++){
            String e = String.valueOf(str.charAt(i));
            if(wordFreq.containsKey(e)){
                int value = wordFreq.get(e);
                wordFreq.put(e,++value);
            }else {
                wordFreq.put(e,1);
            }
        }
        for(int i = 0; i<str_len; i++){
            String e = String.valueOf(str.charAt(i));
            int freq = wordFreq.get(e);
            if(freq == 1){
                System.out.println(e);
                return;
            }
        }

    }

    @Test
    public void test7(){
        String str1 = "abaccdeff";
        firstOnceCharacter(str1);
    }


    public String removeTargetCharacters(){
        String res = "";

        return res;
    }














}
