package csdn.bean;

import org.apache.commons.lang.StringUtils;
import utils.FileHelper;
import utils.SnowflakeIdWorker;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class Alert {
    private String title;//告警标题
    private String text;//告警内容
    private String moIp;//发生ip
    private long occurtime;//时间戳
    private int severity;//0:清除,1:主要,2:次要,3:警告
    private long eventid;//告警id
    private String appSys;//应用系统

    private static SnowflakeIdWorker idWorker = new SnowflakeIdWorker(0, 0);//需要序列化
    private String[] appSysDB = getAppSysDB();


/***********************************************************************************************************/
    public Alert() { }

    protected Alert(String title, String text, String moIp, long occurtime, int severity, long eventid, String appSys) {
        this.title = title;
        this.text = text;
        this.moIp = moIp;
        this.occurtime = occurtime;
        this.severity = severity;
        this.eventid = eventid;
        this.appSys = appSys;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getMoIp() {
        return moIp;
    }

    public void setMoIp(String moIp) {
        this.moIp = moIp;
    }

    public long getOccurtime() {
        return occurtime;
    }

    public void setOccurtime(long occurtime) {
        this.occurtime = occurtime;
    }

    public int getSeverity() {
        return severity;
    }

    public void setSeverity(int severity) {
        this.severity = severity;
    }

    public long getEventid() {
        return eventid;
    }

    public void setEventid(long eventid) {
        this.eventid = eventid;
    }

    public String getAppSys() {
        return appSys;
    }

    public void setAppSys(String appSys) {
        this.appSys = appSys;
    }

    @Override
    public String toString() {
        return "Alert{" +
                "title='" + title + '\'' +
                ", text='" + text + '\'' +
                ", moIp='" + moIp + '\'' +
                ", occurtime=" + occurtime +
                ", severity=" + severity +
                ", eventid=" + eventid +
                ", appSys='" + appSys + '\'' +
                '}';
    }

    /**随机生成ip**/
    protected String getRandomIp(){
        // ip范围
        int[][] range = {
                {607649792, 608174079}, // 36.56.0.0-36.63.255.255
                {1038614528, 1039007743}, // 61.232.0.0-61.237.255.255
                {1783627776, 1784676351}, // 106.80.0.0-106.95.255.255
                {2035023872, 2035154943}, // 121.76.0.0-121.77.255.255
                {2078801920, 2079064063}, // 123.232.0.0-123.235.255.255
                {-1950089216, -1948778497}, // 139.196.0.0-139.215.255.255
                {-1425539072, -1425014785}, // 171.8.0.0-171.15.255.255
                {-1236271104, -1235419137}, // 182.80.0.0-182.92.255.255
                {-770113536, -768606209}, // 210.25.0.0-210.47.255.255
                {-569376768, -564133889}, // 222.16.0.0-222.95.255.255
        };

        Random random = new Random();
        int index = random.nextInt(10);
        String ip = num2ip(range[index][0] + new Random().nextInt(range[index][1] - range[index][0]));
        return ip;
    }

    /*将十进制转换成IP地址*/
    private String num2ip(int ip) {
        int[] b = new int[4];
        String ipStr = "";
        b[0] = (int) ((ip >> 24) & 0xff);
        b[1] = (int) ((ip >> 16) & 0xff);
        b[2] = (int) ((ip >> 8) & 0xff);
        b[3] = (int) (ip & 0xff);
        ipStr = Integer.toString(b[0]) + "." + Integer.toString(b[1]) + "." + Integer.toString(b[2]) + "." + Integer.toString(b[3]);
        return ipStr;
    }


    /**在给定范围内生成随机时间戳**/
    protected long getRandomOccurtime(String start, String end){
        long startTime = Timestamp.valueOf(start).getTime();//"2012-01-01 00:00:00"
        long endTime = Timestamp.valueOf(end).getTime();
        long diff = endTime - startTime + 1;
        Timestamp rand = new Timestamp(startTime + (long)(Math.random() * diff));
        return rand.getTime();
    }



    /** 随机生成告警级别 **/
    private int getRandomSeverity(){
        return new Random().nextInt(3)+1;
    }

    /** 随机生成告id **/
    protected long getRandomEventid(){
        return idWorker.nextId();
    }



    /**随机生成告警标题**/
    protected String getRandomTitle(String appSys, int severity){
        String[] titlePrefixDB = {"维护中","维护转生产","压制未清除",""};
        int pos = new Random().nextInt(titlePrefixDB.length);
        String titlePrefix = titlePrefixDB[pos];
        String severityText = Severity2Text(severity);
        String res = null;
        if(StringUtils.isBlank(titlePrefix)){
            res = String.format("[%s]%s",severityText,appSys);
        }else{
            res = String.format("[%s][%s]%s",titlePrefix,severityText,appSys);
        }

        return res;
    }

    /**随机生成告警内容**/
    protected String getRandomText(String appSys, int severity, long timestamp){
        String[] errorTypeDB = {"进程","Oracle数据库","Mysql数据库","CPU","内存","磁盘","Hadoop集群","Spark集群","Storm集群"};
        String[] typeDB = {"错误提示类","性能类","状态类"};

        int pos1 = new Random().nextInt(errorTypeDB.length);
        String errorType = errorTypeDB[pos1];

        int pos2 = new Random().nextInt(typeDB.length);
        String type = typeDB[pos2];

        String time = Timestamp2Text(timestamp);

        String severityText = Severity2Text(severity);
        String res = null;
        res = String.format("[%s][%s]%s,%s异常,发生时间:%s",severityText,type,appSys,errorType,time);
        return res;
    }

    /**转换告警级别为文字**/
    private String Severity2Text(int severity){
        String res = "";
        switch (severity){
            case 0:
                res = "清除告警";
                break;
            case 1:
                res = "主要告警";
                break;
            case 2:
                res = "次要告警";
                break;
            case 3:
                res = "警告告警";
                break;
        }
        return res;
    }

    /**将时间戳转化为文字**/
    private String Timestamp2Text(long timestamp){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日HH时mm分ss秒");
        return sdf.format(new Date(Long.parseLong(String.valueOf(timestamp))));
    }

    /**获取全量应用系统**/
    private String[] getAppSysDB(){
        FileHelper fileHelper = new FileHelper();
        String content = null;
        try {
            content = fileHelper.getFileContent("target/classes/alert/appSysDB");
        }catch (Exception e){}
        return content.split("\n");
    }

    /** 随机生成应用系统名 **/
    protected String getRandomAppSys(){
        int pos = new Random().nextInt(appSysDB.length);
        return appSysDB[pos];
    }

    public static Alert randomAlert(){
        Alert alert = new Alert();
        long eventid = alert.getRandomEventid();
        int severity = alert.getRandomSeverity();
        long timestamp = alert.getRandomOccurtime("2020-01-01 00:00:00","2021-01-01 00:00:00");
        String moIp = alert.getRandomIp();
        String appSys = alert.getRandomAppSys();
        String title = alert.getRandomTitle(appSys,severity);
        String text = alert.getRandomText(appSys,severity,timestamp);

        return new Alert(title,text,moIp,timestamp,severity,eventid,appSys);
    }




























































}
