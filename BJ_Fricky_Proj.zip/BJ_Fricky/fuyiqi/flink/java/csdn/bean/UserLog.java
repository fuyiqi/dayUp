package csdn.bean;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class UserLog {

    private String name;
    private String ip;
    private String targetUrl;
    private String date_time;


    private String[] nameDB = {
            "Aaron",
            "Abel",
            "Abraham",
            "Adam",
            "Adrian",
            "Aidan",
            "Alva",
            "Alex",
            "Alexander",
            "Alan",
            "Albert",
            "Alfred",
            "Andrew",
            "Andy",
            "Angus",
            "Anthony",
            "Apollo",
            "Arnold",
            "Arthur",
            "August",
            "Austin",
            "Ben",
            "Benjamin",
            "Bert",
            "Benson",
            "Bill",
            "Billy",
            "Blake",
            "Bob",
            "Bobby",
            "Brad",
            "Brandon",
            "Brant",
            "Brent",
            "Brian",
            "Brown",
            "Bruce",
            "Caleb",
            "Cameron",
            "Carl",
            "Carlos",
            "Cary",
            "Caspar",
            "Cecil",
            "Charles",
            "Cheney",
            "Chris",
            "Christian",
            "Christopher",
            "Clark",
            "Cliff",
            "Cody",
            "Cole",
            "Colin",
            "Cosmo",
            "Daniel",
            "Denny",
            "Darwin",
            "David",
            "Dennis",
            "Derek",
            "Dick",
            "Donald",
            "Douglas",
            "Duke",
            "Dylan",
            "Eddie",
            "Edgar",
            "Edison",
            "Edmund",
            "Edward",
            "Edwin",
            "Elijah",
            "Elliott",
            "Elvis",
            "Eric",
            "Ethan",
            "Eugene",
            "Evan",
            "Enterprise",
            "Ford",
            "Francis",
            "Frank",
            "Franklin",
            "Fred",
            "Gabriel",
            "Gaby",
            "Garfield",
            "Gary",
            "Gavin",
            "Geoffrey",
            "George",
            "Gino",
            "Glen",
            "Glendon",
            "Hank",
            "Hardy",
            "Harrison",
            "Harry",
            "Hayden",
            "Henry",
            "Hilton",
            "Hugo",
            "Hunk",
            "Howard",
            "Henry",
            "Ian",
            "Ignativs",
            "Ivan",
            "Isaac",
            "Isaiah",
            "Jack",
            "Jackson",
            "Jacob",
            "James",
            "Jason",
            "Jay",
            "Jeffery",
            "Jerome",
            "Jerry",
            "Jesse",
            "Jim",
            "Jimmy",
            "Joe",
            "John",
            "Johnny",
            "Jonathan",
            "Jordan",
            "Jose",
            "Joshua",
            "Justin",
            "Keith",
            "Ken",
            "Kennedy",
            "Kenneth",
            "Kenny",
            "Kevin",
            "Kyle",
            "Lance",
            "Larry",
            "Laurent",
            "Lawrence",
            "Leander",
            "Lee",
            "Leo",
            "Leonard",
            "Leopold",
            "Leslie",
            "Loren",
            "Lori",
            "Lorin",
            "Louis",
            "Luke",
            "Marcus",
            "Marcy",
            "Mark",
            "Marks",
            "Mars",
            "Marshal",
            "Martin",
            "Marvin",
            "Mason",
            "Matthew",
            "Max",
            "Michael",
            "Mickey",
            "Mike",
            "Nathan",
            "Nathaniel",
            "Neil",
            "Nelson",
            "Nicholas",
            "Nick",
            "Noah",
            "Norman",
            "Oliver",
            "Oscar",
            "Owen",
            "Patrick",
            "Paul",
            "Peter",
            "Philip",
            "Phoebe",
            "Quentin",
            "Randall",
            "Randolph",
            "Randy",
            "Ray",
            "Raymond",
            "Reed",
            "Rex",
            "Richard",
            "Richie",
            "Riley",
            "Robert",
            "Robin",
            "Robinson",
            "Rock",
            "Roger",
            "Ronald",
            "Rowan",
            "Roy",
            "Ryan",
            "Sam",
            "Sammy",
            "Samuel",
            "Scott",
            "Sean",
            "Shawn",
            "Sidney",
            "Simon",
            "Solomon",
            "Spark",
            "Spencer",
            "Spike",
            "Stanley",
            "Steve",
            "Steven",
            "Stewart",
            "Stuart",
            "Terence",
            "Terry",
            "Ted",
            "Thomas",
            "Tim",
            "Timothy",
            "Todd",
            "Tommy",
            "Tom",
            "Thomas",
            "Tony",
            "Tyler",
            "Ultraman",
            "Ulysses",
            "Van",
            "Vern",
            "Vernon",
            "Victor",
            "Vincent",
            "Warner",
            "Warren",
            "Wayne",
            "Wesley",
            "William",
            "Willy",
            "Zack",
            "Zachary",
            "Abigail",
            "Abby",
            "Ada",
            "Adelaide",
            "Adeline",
            "Alexandra",
            "Ailsa",
            "Aimee",
            "Alexis",
            "Alice",
            "Alicia",
            "Alina",
            "Allison",
            "Alyssa",
            "Amanda",
            "Amy",
            "Amber",
            "Anastasia",
            "Andrea",
            "Angel",
            "Angela",
            "Angelia",
            "Angelina",
            "Ann",
            "Anna",
            "Anne",
            "Annie",
            "Anita",
            "Ariel",
            "April",
            "Ashley",
            "Audrey",
            "Aviva",
            "Barbara",
            "Barbie",
            "Beata",
            "Beatrice",
            "Becky",
            "Bella",
            "Bess",
            "Bette",
            "Betty",
            "Blanche",
            "Bonnie",
            "Brenda",
            "Brianna",
            "Britney",
            "Brittany",
            "Camille",
            "Candice",
            "Candy",
            "Carina",
            "Carmen",
            "Carol",
            "Caroline",
            "Carry",
            "Carrie",
            "Cassandra",
            "Cassie",
            "Catherine",
            "Cathy",
            "Chelsea",
            "Charlene",
            "Charlotte",
            "Cherry",
            "Cheryl",
            "Chloe",
            "Chris",
            "Christina",
            "Christine",
            "Christy",
            "Cindy",
            "Claire",
            "Claudia",
            "Clement",
            "Cloris",
            "Connie",
            "Constance",
            "Cora",
            "Corrine",
            "Crystal",
            "Daisy",
            "Daphne",
            "Darcy",
            "Dave",
            "Debbie",
            "Deborah",
            "Debra",
            "Demi",
            "Diana",
            "Dolores",
            "Donna",
            "Dora",
            "Doris",
            "Edith",
            "Editha",
            "Elaine",
            "Eleanor",
            "Elizabeth",
            "Ella",
            "Ellen",
            "Ellie",
            "Emerald",
            "Emily",
            "Emma",
            "Enid",
            "Elsa",
            "Erica",
            "Estelle",
            "Esther",
            "Eudora",
            "Eva",
            "Eve",
            "Evelyn",
            "Fannie",
            "Fay",
            "Fiona",
            "Flora",
            "Florence",
            "Frances",
            "Frederica",
            "Frieda",
            "Flta",
            "Gina",
            "Gillian",
            "Gladys",
            "Gloria",
            "Grace",
            "Grace",
            "Greta",
            "Gwendolyn",
            "Hannah",
            "Haley",
            "Hebe",
            "Helena",
            "Hellen",
            "Henna",
            "Heidi",
            "Hillary",
            "Ingrid",
            "Isabella",
            "Ishara",
            "Irene",
            "Iris",
            "Ivy",
            "Jacqueline",
            "Jade",
            "Jamie",
            "Jane",
            "Janet",
            "Jasmine",
            "Jean",
            "Jenna",
            "Jennifer",
            "Jenny",
            "Jessica",
            "Jessie",
            "Jill",
            "Joan",
            "Joanna",
            "Jocelyn",
            "Joliet",
            "Josephine",
            "Josie",
            "Joy",
            "Joyce",
            "Judith",
            "Judy",
            "Julia",
            "Juliana",
            "Julie",
            "June",
            "Karen",
            "Karida",
            "Katherine",
            "Kate",
            "Kathy",
            "Katie",
            "Katrina",
            "Kay",
            "Kayla",
            "Kelly",
            "Kelsey",
            "Kimberly",
            "Kitty",
            "Lareina",
            "Lassie",
            "Laura",
            "Lauren",
            "Lena",
            "Lydia",
            "Lillian",
            "Lily",
            "Linda",
            "lindsay",
            "Lisa",
            "Liz",
            "Lora",
            "Lorraine",
            "Louisa",
            "Louise",
            "Lucia",
            "Lucy",
            "Lucine",
            "Lulu",
            "Lydia",
            "Lynn",
            "Mabel",
            "Madeline",
            "Maggie",
            "Mamie",
            "Manda",
            "Mandy",
            "Margaret",
            "Mariah",
            "Marilyn",
            "Martha",
            "Mavis",
            "Mary",
            "Matilda",
            "Maureen",
            "Mavis",
            "Maxine",
            "May",
            "Mayme",
            "Megan",
            "Melinda",
            "Melissa",
            "Melody",
            "Mercedes",
            "Meredith",
            "Mia",
            "Michelle",
            "Milly",
            "Miranda",
            "Miriam",
            "Miya",
            "Molly",
            "Monica",
            "Morgan",
            "Nancy",
            "Natalie",
            "Natasha",
            "Nicole",
            "Nikita",
            "Nina",
            "Nora",
            "Norma",
            "Nydia",
            "Octavia",
            "Olina",
            "Olivia",
            "Ophelia",
            "Oprah",
            "Pamela",
            "Patricia",
            "Patty",
            "Paula",
            "Pauline",
            "Pearl",
            "Peggy",
            "Philomena",
            "Phoebe",
            "Phyllis",
            "Polly",
            "Priscilla",
            "Quentina",
            "Rachel",
            "Rebecca",
            "Regina",
            "Rita",
            "Rose",
            "Roxanne",
            "Ruth",
            "Sabrina",
            "Sally",
            "Sandra",
            "Samantha",
            "Sami",
            "Sandra",
            "Sandy",
            "Sarah",
            "Savannah",
            "Scarlett",
            "Selma",
            "Selina",
            "Serena",
            "Sharon",
            "Sheila",
            "Shelley",
            "Sherry",
            "Shirley",
            "Sierra",
            "Silvia",
            "Sonia",
            "Sophia",
            "Stacy",
            "Stella",
            "Stephanie",
            "Sue",
            "Sunny",
            "Susan",
            "Tamara",
            "Tammy",
            "Tanya",
            "Tasha",
            "Teresa",
            "Tess",
            "Tiffany",
            "Tina",
            "Tonya",
            "Tracy",
            "Ursula",
            "Vanessa",
            "Venus",
            "Vera",
            "Vicky",
            "Victoria",
            "Violet",
            "Virginia",
            "Vita",
            "Vivian"
    };

    private String[] urlDB = {
            "i.com.cn",
            "j.com.cn",
            "o.com.cn",
            "u.com.cn",
            "y.com.cn",
            "x.com.cn",
            "s.com.cn",
            "z.com.cn",
            "l.com.cn",
            "t.com.cn"
    };


    public UserLog(String name, String ip, String targetUrl, String date_time) {
        this.name = name;
        this.ip = ip;
        this.targetUrl = targetUrl;
        this.date_time = date_time;
    }

    @Override
    public String toString() {
        return "UserLog{" +
                "name='" + name + '\'' +
                ", ip='" + ip + '\'' +
                ", targetUrl='" + targetUrl + '\'' +
                ", date_time='" + date_time + '\'' +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getTargetUrl() {
        return targetUrl;
    }

    public void setTargetUrl(String targetUrl) {
        this.targetUrl = targetUrl;
    }

    public String getDate_time() {
        return date_time;
    }

    public void setDate_time(String date_time) {
        this.date_time = date_time;
    }


    /**随机生成ip**/
    protected String getRandomIp(){
        // ip范围
        int[][] range = {
                {607649792, 608174079}, // 36.56.0.0-36.63.255.255
                {1038614528, 1039007743}, // 61.232.0.0-61.237.255.255
                {1783627776, 1784676351}, // 106.80.0.0-106.95.255.255
                {2035023872, 2035154943}, // 121.76.0.0-121.77.255.255
                {2078801920, 2079064063}, // 123.232.0.0-123.235.255.255
                {-1950089216, -1948778497}, // 139.196.0.0-139.215.255.255
                {-1425539072, -1425014785}, // 171.8.0.0-171.15.255.255
                {-1236271104, -1235419137}, // 182.80.0.0-182.92.255.255
                {-770113536, -768606209}, // 210.25.0.0-210.47.255.255
                {-569376768, -564133889}, // 222.16.0.0-222.95.255.255
        };

        Random random = new Random();
        int index = random.nextInt(10);
        String ip = num2ip(range[index][0] + new Random().nextInt(range[index][1] - range[index][0]));
        return ip;
    }

    /*将十进制转换成IP地址*/
    private String num2ip(int ip) {
        int[] b = new int[4];
        String ipStr = "";
        b[0] = (int) ((ip >> 24) & 0xff);
        b[1] = (int) ((ip >> 16) & 0xff);
        b[2] = (int) ((ip >> 8) & 0xff);
        b[3] = (int) (ip & 0xff);
        ipStr = Integer.toString(b[0]) + "." + Integer.toString(b[1]) + "." + Integer.toString(b[2]) + "." + Integer.toString(b[3]);
        return ipStr;
    }

    /**在给定范围内生成随机时间串**/
    protected String getRandomDateStr(String start, String end){
        String timeStr = null;
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            Date startDate = format.parse(start);
            Date endDate = format.parse(end);
            long timeNum = random(startDate.getTime(),endDate.getTime());
            timeStr = format.format(timeNum);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return timeStr;
    }

    private long random(long begin,long end){
        long rtn = begin + (long)(Math.random() * (end - begin));
        if(rtn == begin || rtn == end){
            return random(begin,end);
        }
        return rtn;
    }

    protected String getRandomName(){
        int pos = new Random().nextInt(nameDB.length);
        return nameDB[pos];
    }

    protected String getRandomUrl(){
        int pos = new Random().nextInt(urlDB.length);
        return urlDB[pos];
    }

    public UserLog() {
    }

    public static String nextUserLog(){
        UserLog ulog = new UserLog();
        String usrName = ulog.getRandomName();
        String usrUrl = ulog.getRandomUrl();
        String usrIp = ulog.getRandomIp();
        String usrTime = ulog.getRandomDateStr("2020-01-01 00:00:00","2021-01-01 00:00:00");

        return usrIp+","+usrName+","+usrUrl+","+usrTime;
    }

















}
