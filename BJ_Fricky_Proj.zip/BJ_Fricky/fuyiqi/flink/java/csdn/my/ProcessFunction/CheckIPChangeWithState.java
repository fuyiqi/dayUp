package csdn.my.ProcessFunction;

import csdn.bean.UserLog;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.streaming.api.functions.source.ParallelSourceFunction;

import org.apache.flink.util.Collector;
import org.testng.annotations.Test;

import java.util.*;


/**
 * 根据登录日志，将同一个用户连续的两次不同ip登录打印出来
 * **/


public class CheckIPChangeWithState {

    static class UserLoginRecord{
        private String ip;
        private String username;
        private String targetUrl;
        private String date_time;

        public UserLoginRecord(String ip, String username, String targetUrl, String date_time) {
            this.ip = ip;
            this.username = username;
            this.targetUrl = targetUrl;
            this.date_time = date_time;
        }

        public String getIp() {
            return ip;
        }

        public void setIp(String ip) {
            this.ip = ip;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getTargetUrl() {
            return targetUrl;
        }

        public void setTargetUrl(String targetUrl) {
            this.targetUrl = targetUrl;
        }

        public String getDate_time() {
            return date_time;
        }

        public void setDate_time(String date_time) {
            this.date_time = date_time;
        }


        @Override
        public String toString() {
            return "UserLoginRecord{" +
                    "ip='" + ip + '\'' +
                    ", username='" + username + '\'' +
                    ", targetUrl='" + targetUrl + '\'' +
                    ", date_time='" + date_time + '\'' +
                    '}';
        }
    }



    @Test
    public void run1() throws Exception {
        StreamExecutionEnvironment exeEnv = StreamExecutionEnvironment.getExecutionEnvironment();
        //1.定义数据源
        DataStreamSource<String> dataStream = exeEnv.addSource(new usrLogParallelSourceFunction()).setParallelism(8);
        /**数据格式
         * 192.168.11.2,fuyiqi,http://www.cmbc.com.cn,2021-01-22 13:02:01
         * **/
        //2.数据处理
        dataStream.map(
                new MapFunction<String, Tuple2<String,UserLoginRecord>>(){
                    @Override
                    public Tuple2<String,UserLoginRecord> map(String value) throws Exception {
                        String[] record = value.split(",");
                        String ip = record[0].trim();
                        String username = record[1].trim();
                        String targetUrl = record[2].trim();
                        String date_time = record[3].trim();
                        return new Tuple2<>(ip,new UserLoginRecord(ip,username,targetUrl,date_time));
                    }
                }
        ).keyBy(
                new KeySelector<Tuple2<String, UserLoginRecord>, UserLoginRecord>() {
                    @Override
                    public UserLoginRecord getKey(Tuple2<String, UserLoginRecord> value) throws Exception {
                        return value.getField(1);
                    }
                }
        ).process(new KeyedProcessFunction<UserLoginRecord, Tuple2<String, UserLoginRecord>, Tuple2<String, UserLoginRecord>>() {
            ListState<UserLoginRecord> myState;
            @Override
            public void open(Configuration parameters) throws Exception {
                super.open(parameters);
                myState = getRuntimeContext().getListState(
                        new ListStateDescriptor<UserLoginRecord>("changeIP",UserLoginRecord.class)
                );

            }

            //解析用户访问信息
            public void processElement(Tuple2<String, UserLoginRecord> value, Context ctx, Collector<Tuple2<String, UserLoginRecord>> out) throws Exception {
                List<UserLoginRecord> logins = new ArrayList<>();

                logins.add(value.f1);
                Comparator<UserLoginRecord> byTime = Comparator.comparing(UserLoginRecord::getDate_time);
                logins.sort(byTime);

                if(logins.size()==2){
                    UserLoginRecord first = logins.get(0);
                    UserLoginRecord second = logins.get(1);
                    if(!first.ip.equals(second.ip)){//
                        System.out.println("ip有变化，第一次："+first.toString()+";第二次："+second.toString());
                    }
                    //移除第一个，保留第二个
                    logins.removeAll(Collections.EMPTY_LIST);
                    logins.add(second);
                    myState.update(logins);
                }

                out.collect(value);

            }

        })
                .print().setParallelism(1);




        exeEnv.execute("checkIP");


    }


    static class usrLogParallelSourceFunction implements ParallelSourceFunction<String> {
        private volatile boolean isRunning = true;
        private static UserLog userLog = new UserLog();
        @Override
        public void run(SourceContext<String> ctx) throws Exception {
            while (isRunning){
                ctx.collect(userLog.nextUserLog());
            }
        }

        @Override
        public void cancel() {
            isRunning = false;
        }
    }










}
