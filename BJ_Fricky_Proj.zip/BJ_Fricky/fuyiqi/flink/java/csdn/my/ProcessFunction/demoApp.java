package csdn.my.ProcessFunction;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.streaming.api.functions.source.ParallelSourceFunction;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.streaming.api.watermark.Watermark;
import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;
import org.apache.flink.util.StringUtils;
import org.testng.annotations.Test;
import utils.MyJavaStreamExecutionLocalEnvironment;

import javax.annotation.Nullable;
import java.io.IOException;
import java.util.Random;

public class demoApp {

    /**使用低阶算子ProcessFunction实现高阶filter算子**/
    @Test
    public void run1(){

        //创建本地运行带web
        final StreamExecutionEnvironment env = MyJavaStreamExecutionLocalEnvironment.getInstance();

        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);//采用在数据流中的时间

        env.setParallelism(1);//设置并行度为1
        //添加数据源
        DataStream<Tuple2<String,Integer>>dataStream =  env.addSource(
                new SourceFunction<Tuple2<String,Integer>>() {
                    @Override
                    public void run(SourceContext<Tuple2<String,Integer>> ctx) throws Exception {
                        int i = 0;
                        while (true){
                            String name = "name:"+i;
                            Integer value = i++;
                            long cur_timestamp = System.currentTimeMillis();
                            //打印数据和时间戳，便于校验
                            System.out.println(
                                    String.format("[Source_Phase]name=%s, cur_timestamp=%s",
                                    name,cur_timestamp)
                            );

                            ctx.collectWithTimestamp(new Tuple2<String,Integer>(name,value),cur_timestamp);
                            Thread.sleep(10);
                        }
                    }

                    @Override
                    public void cancel() {

                    }
                }
        );

        dataStream.process(new ProcessFunction<Tuple2<String, Integer>, String>() {
            @Override
            public void processElement(Tuple2<String, Integer> value, Context ctx, Collector<String> out) throws Exception {
                if(0 == (value.f1%2)){//奇数元素不得进入下一个算子阶段
                    out.collect(
                            String.format("[Ops.ProcessElement_Phase] value=%s, cur_timestamp=%s",
                                    value.f0,ctx.timestamp())
                    );
                }
            }
        }).print().setParallelism(1);

        //提交job任务
        try {
            env.execute("app1");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    /**
     * 对于一个DataStream来说，可以通过旁路输出将数据输出到其他算子中去，而不影响原有的算子的处理
     * **/
    @Test
    public void run2(){
        //创建本地运行带web
        final StreamExecutionEnvironment env = MyJavaStreamExecutionLocalEnvironment.getInstance();
        env.setParallelism(1);//设置并行度为1
        //添加数据源
        DataStream<Tuple2<String,Integer>>dataStream =  env.addSource(
                new SourceFunction<Tuple2<String,Integer>>() {
                    @Override
                    public void run(SourceContext<Tuple2<String,Integer>> ctx) throws Exception {
                        int i = 0;
                        while (true){
                            String name = "name:"+i;
                            Integer value = i++;

                            ctx.collect(new Tuple2<String,Integer>(name,value));
                            Thread.sleep(10);
                        }
                    }

                    @Override
                    public void cancel() {

                    }
                }
        );
        final OutputTag<String> evenSideOutput = new OutputTag<String>("evenSideOutput"){};

        SingleOutputStreamOperator<String> mainStream = dataStream.process(
                new ProcessFunction<Tuple2<String, Integer>, String>() {
                    @Override
                    public void processElement(Tuple2<String, Integer> value, Context ctx, Collector<String> out) throws Exception {
                        //进入主流程的下一个算子
                        out.collect(String.format("[MainOps_Phase]name:%s, value:%d",value.f0,value.f1));
                        if(0 == (value.f1%2)){//偶数元素进入下一个旁路算子阶段
                            ctx.output(evenSideOutput,String.format("[evenSideOutput_Phase]name:%s, value:%d",value.f0,value.f1));
                        }

                    }
                }
        );
        //禁止chanin，这样可以在页面上看清楚原始的DAG
        mainStream.disableChaining();
        //获取旁路数据
        DataStream<String> evenSideStream = mainStream.getSideOutput(evenSideOutput);
        mainStream.print();
        evenSideStream.print();

        //提交job任务
        try {
            env.execute("app2");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //KeyedProcessFunction和ProcessFunction并无直接关系
    @Test
    public void run3() throws Exception {
        final StreamExecutionEnvironment env = MyJavaStreamExecutionLocalEnvironment.getInstance();
        // 于算子而言,处理时间则取机器的当前时钟时间
        env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);

        DataStream<String> dataStream = env.addSource(new RandomSource()).setParallelism(8);
        dataStream.flatMap(new Splitter())
                //设置时间戳分配器，使用当前的机器时钟作为时间戳
                .assignTimestampsAndWatermarks(new AssignerWithPeriodicWatermarks<Tuple2<String, Integer>>() {
                    //不使用watermark
                    @Nullable
                    @Override
                    public Watermark getCurrentWatermark() {
                        return null;
                    }
                    //当前的机器时钟
                    @Override
                    public long extractTimestamp(Tuple2<String, Integer> element, long previousElementTimestamp) {
                        return System.currentTimeMillis();
                    }
                }).keyBy(0)//使用单词作为key
                .process(new CountWithTimeoutFunction())//搂出超时10s的
                .print()
        ;

        env.execute("he");
    }

    /**bean
     * **/
    static class CountWithTimestamp{
        public String key;
        public long count;
        public long lastModified;
    }

    static class RandomSource implements ParallelSourceFunction<String> {
        private volatile boolean isRunning = true;

        @Override
        public void run(SourceContext ctx) throws Exception {
            while (true) {
                //生成指定长度的字母和数字的随机组合字符串
                String str1 = RandomStringUtils.randomAlphanumeric(new Random().nextInt(9) + 1);
                String str2 = RandomStringUtils.randomAlphanumeric(new Random().nextInt(9) + 1);
                String str3 = RandomStringUtils.randomAlphanumeric(new Random().nextInt(9) + 1);
                ctx.collect(str1 + "\t" + str2 + " " + str3);
                Thread.sleep(10);
            }
        }

        @Override
        public void cancel() {
            isRunning = false;
        }
    }

    static class Splitter implements FlatMapFunction<String,Tuple2<String, Integer>>{

        @Override
        public void flatMap(String value, Collector<Tuple2<String, Integer>> out) throws Exception {
            if(StringUtils.isNullOrWhitespaceOnly(value)) {
                System.out.println("invalid line");
                return;
            }

            for(String word:value.split("\t| ")){
                out.collect(new Tuple2<String, Integer>(word,1));
            }


        }
    }

    class CountWithTimeoutFunction extends KeyedProcessFunction<Tuple, Tuple2<String, Integer>, Tuple2<String, Long>> {
        // 自定义状态
        private ValueState<CountWithTimestamp> state;

        public void open(Configuration parameters) throws Exception{
            super.open(parameters);
            // 初始化状态，name是myState
            state = getRuntimeContext().getState(new ValueStateDescriptor<CountWithTimestamp>("myState",CountWithTimestamp.class));
        }

        @Override
        public void processElement(
                Tuple2<String, Integer> value,
                Context ctx,
                Collector<Tuple2<String, Long>> out
        ) throws Exception {
            // 取得当前是哪个单词
            Tuple currentKey = ctx.getCurrentKey();
            // 从backend取得当前单词的myState状态
            CountWithTimestamp current = state.value();
            // 如果myState还从未没有赋值过，就在此初始化
            if (current == null) {
                current = new CountWithTimestamp();
                current.key = value.f0;
            }

            // 单词数量加一
            current.count++;

            // 取当前元素的时间戳，作为该单词最后一次出现的时间
            current.lastModified = ctx.timestamp();

            // 重新保存到backend，包括该单词出现的次数，以及最后一次出现的时间
            state.update(current);

            // 为当前单词创建定时器，十秒后后触发
            long timer = current.lastModified + 10000;
            ctx.timerService().registerProcessingTimeTimer(timer);

        }

        /**定时器触发后执行的方法**/
        public void onTimer(
                long timestamp,
                OnTimerContext ctx,
                Collector<Tuple2<String, Long>> out
        ) throws Exception {
            // 取得当前单词
            Tuple currentKey = ctx.getCurrentKey();
            // 取得该单词的myState状态
            CountWithTimestamp result = state.value();
            // 当前元素是否已经连续10秒未出现的标志
            boolean isTimeout = false;

            /** timestamp是定时器触发时间，如果等于最后一次更新时间+10秒，就表示这十秒内已经收到过该单词了，
            这种连续十秒没有出现的元素，被发送到下游算子**/
            if (timestamp == result.lastModified + 10000) {
                // 发送
                out.collect(new Tuple2<String, Long>(result.key, result.count));
                isTimeout = true;
            }


        }




    }



































































}
