package csdn.my.Cep;

import org.apache.flink.cep.CEP;
import org.apache.flink.cep.PatternFlatSelectFunction;
import org.apache.flink.cep.PatternSelectFunction;
import org.apache.flink.cep.PatternStream;
import org.apache.flink.cep.pattern.Pattern;
import org.apache.flink.cep.pattern.conditions.IterativeCondition;
import org.apache.flink.cep.pattern.conditions.SimpleCondition;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.ParallelSourceFunction;
import org.apache.flink.util.Collector;
import org.testng.annotations.Test;
import csdn.bean.Alert;
import utils.MyJavaStreamExecutionLocalEnvironment;

import java.util.List;
import java.util.Map;

public class demoApp {


    /**自造的告警数据流**/
    public static class AlertParallelSourceFunction implements ParallelSourceFunction<Alert> {
        private static Alert alertBase = new Alert();//需要序列化
        private volatile boolean isRunning = true;

        @Override
        public void run(SourceContext<Alert> ctx) throws Exception {
            while (isRunning){
                synchronized (ctx.getCheckpointLock()){
                    ctx.collect(alertBase.randomAlert());
                    //Thread.sleep(1000);
                }
            }
        }

        @Override
        public void cancel() {
            isRunning = false;
        }


    }







    @Test
    public void demo() throws Exception {
        final StreamExecutionEnvironment exeEnv = MyJavaStreamExecutionLocalEnvironment.getInstance();;
        //1.定义事件流
        DataStream<Alert> alertStream = exeEnv.addSource(new AlertParallelSourceFunction()).setParallelism(8);
        //2.定义pattern
        Pattern<Alert, Alert> myPattern = Pattern.<Alert>begin("start").where(
                new SimpleCondition<Alert>() {
                    @Override
                    public boolean filter(Alert value) throws Exception {
                        return value.getAppSys().contains("集中监控");
                    }
                }
        );
        //3.把pattern应用在事件流
        PatternStream<Alert> patternStream = CEP.pattern(alertStream,myPattern);
        //4.将符合pattern的事件流拿出来
        patternStream.select(
                new PatternSelectFunction<Alert, String>() {
                    @Override
                    public String select(Map<String, List<Alert>> pattern) throws Exception {
                        List<Alert> hit = pattern.get("start");
                        return hit.toString();
                    }
                }
        ).print();

        exeEnv.execute("h1");


    }

    @Test
    public void general() throws Exception {
        final StreamExecutionEnvironment exeEnv = MyJavaStreamExecutionLocalEnvironment.getInstance();;
        //1.定义事件流
        DataStream<Alert> alertStream = exeEnv.addSource(new AlertParallelSourceFunction()).setParallelism(8);
        //2.定义pattern
        Pattern<Alert, Alert> myPattern = Pattern.<Alert>begin("alertStream").where(
                new IterativeCondition<Alert>(){

                    @Override
                    public boolean filter(Alert value, Context<Alert> ctx) throws Exception {
                        return value.getAppSys().contains("集中监控");
                    }
                }
        ).next("alertTitleProcess").subtype(Alert.class).where(
                new SimpleCondition<Alert>() {
                    @Override
                    public boolean filter(Alert value) throws Exception {
                        return value.getTitle().contains("维护中");
                    }
                }
        );
        //3.把pattern应用在事件流
        PatternStream<Alert> patternStream = CEP.pattern(alertStream,myPattern);
        //4.匹配
/*        patternStream.process(//保存处理的每个阶段
                new PatternProcessFunction<Alert,Object>(){
                    @Override
                    public void processMatch(Map<String, List<Alert>> match, Context ctx, Collector<Object> out) throws Exception {
                        out.collect(match.toString());
                    }
                }
        ).print().setParallelism(1);*/

        patternStream.flatSelect(
                new PatternFlatSelectFunction<Alert,String>(){

                    @Override
                    public void flatSelect(Map<String, List<Alert>> pattern, Collector<String> out) throws Exception {
                        pattern.forEach((phase,value)->{
                            if(phase.equals("alertTitleProcess")){
                                out.collect(value.toString());
                            }
                        });
                    }
                }
        ).print().setParallelism(1);



        exeEnv.execute("h1");


    }











}
