package csdn.pre._2;

import org.apache.flink.api.java.ExecutionEnvironment;
import org.testng.annotations.Test;

public class DataSetSinkJavaApp {

    @Test
    public void test1_env() throws Exception {
        ExecutionEnvironment exeEnv = ExecutionEnvironment.getExecutionEnvironment();

    }






}
