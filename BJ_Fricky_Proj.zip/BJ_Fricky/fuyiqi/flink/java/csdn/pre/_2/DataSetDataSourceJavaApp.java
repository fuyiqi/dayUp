package csdn.pre._2;

import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.configuration.Configuration;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

public class DataSetDataSourceJavaApp {
    @Test
    public void test1_Env() throws Exception {
        ExecutionEnvironment exeEnv = ExecutionEnvironment.getExecutionEnvironment();
        fromMyCollection(exeEnv);
    }

    public void fromMyCollection(ExecutionEnvironment exeEnv) throws Exception {
        List<Integer> list = new ArrayList<>();
        for(int i=1;i<=10;i++){
            list.add(i);
        }
        exeEnv.fromCollection(list).print();
    }

    @Test
    public void test2_Env() throws Exception {
        ExecutionEnvironment exeEnv = ExecutionEnvironment.getExecutionEnvironment();
        readMyTextFile(exeEnv);
    }

    public void readMyTextFile(ExecutionEnvironment exeEnv) throws Exception {
        String path = "fuyiqi/resources/multiFiles";
        exeEnv.readTextFile(path).print();
    }

    @Test
    public void test3_Env() throws Exception {
        ExecutionEnvironment exeEnv = ExecutionEnvironment.getExecutionEnvironment();
        readMyRecrusiveDirTextFile(exeEnv);
    }

    /**读取递归文件夹的内容**/
    public void readMyRecrusiveDirTextFile(ExecutionEnvironment exeEnv) throws Exception {
        String path = "fuyiqi/resources/recrusiveDir1";
        Configuration parameters = new Configuration();
        parameters.setBoolean("recursive.file.enumeration",true);
        exeEnv.readTextFile(path).withParameters(parameters).print();
    }

    @Test
    public void test4_Env() throws Exception {
        ExecutionEnvironment exeEnv = ExecutionEnvironment.getExecutionEnvironment();
        readMyCompressedTextFile(exeEnv);
    }

    /**读取压缩文件中的内容**/
    public void readMyCompressedTextFile(ExecutionEnvironment exeEnv) throws Exception {
        String path = "fuyiqi/resources/compressFile";
        exeEnv.readTextFile(path).print();
    }




























}
