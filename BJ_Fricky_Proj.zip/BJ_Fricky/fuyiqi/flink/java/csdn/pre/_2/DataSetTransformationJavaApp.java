package csdn.pre._2;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.MapPartitionFunction;
import org.apache.flink.api.common.operators.Order;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.util.Collector;
import org.testng.annotations.Test;
import utils.DBUtil;

import java.util.ArrayList;
import java.util.List;

public class DataSetTransformationJavaApp {


    @Test
    public void test1_env() throws Exception {
        ExecutionEnvironment exeEnv = ExecutionEnvironment.getExecutionEnvironment();
        myMapFunction(exeEnv);
    }

    public void myMapFunction(ExecutionEnvironment exeEnv) throws Exception {
        List<Integer> list = new ArrayList<>();
        for(int i=1;i<=10;i++){
            list.add(i);
        }
        DataSource<Integer> dataSource = exeEnv.fromCollection(list);
        //dataSource.map(x->x+1).print();
        dataSource.map(
                new MapFunction<Integer, Integer>() {//第一个是输入，第二个是输出
                    @Override
                    public Integer map(Integer value) throws Exception {
                        return value+1;
                    }
                }
        ).print();
    }

    @Test
    public void test2_env() throws Exception {
        ExecutionEnvironment exeEnv = ExecutionEnvironment.getExecutionEnvironment();
        myFilterFunction(exeEnv);
    }

    public void myFilterFunction(ExecutionEnvironment exeEnv) throws Exception{
        List<Integer> list = new ArrayList<>();
        for(int i=1;i<=10;i++){
            list.add(i);
        }
        DataSource<Integer> dataSource = exeEnv.fromCollection(list);
/*        dataSource.map(
                new MapFunction<Integer,Integer>(){
                    @Override
                    public Integer map(Integer value) throws Exception {
                        return value-2;
                    }
                }
        ).filter(
                new FilterFunction<Integer>() {
                    @Override
                    public boolean filter(Integer value) throws Exception {
                        return value>5;
                    }
                }
        ).print();*/
        dataSource.map(x->x-2).filter(x->x>5).print();

    }

    @Test
    public  void test3_env() throws Exception {
        ExecutionEnvironment exeEnv = ExecutionEnvironment.getExecutionEnvironment();
        myMapPartitionFunction(exeEnv);
    }

    public static void myMapPartitionFunction(ExecutionEnvironment exeEnv) throws Exception {
        List<String> students = new ArrayList<String>();
        for(int i=1;i<=5;i++){
            students.add("student="+i);
        }
        DataSource<String> dataSource = exeEnv.fromCollection(students).setParallelism(4);

       dataSource.mapPartition(
                new MapPartitionFunction<String, String>() {
                    @Override
                    public void mapPartition(Iterable<String> values, Collector<String> out) throws Exception {
                        String connenction = DBUtil.getConnection();
                        System.out.println(connenction);
                        System.out.println("******");
                    }
                }
        ).print();
    }


    @Test
    public  void test4_env() throws Exception {
        ExecutionEnvironment exeEnv = ExecutionEnvironment.getExecutionEnvironment();
        myFirstFunction(exeEnv);
    }

    public void myFirstFunction(ExecutionEnvironment exeEnv) throws Exception {
        List<Tuple2<Integer,String>> list = new ArrayList<Tuple2<Integer,String>>();
        list.add(new Tuple2(1,"Hadoop"));
        list.add(new Tuple2(1,"Spark"));
        list.add(new Tuple2(1,"Flink"));
        list.add(new Tuple2(2,"Linux"));
        list.add(new Tuple2(2,"Windows"));
        list.add(new Tuple2(2,"Unix"));
        list.add(new Tuple2(3,"Java"));
        list.add(new Tuple2(3,"Scala"));
        list.add(new Tuple2(3,"Python"));

        DataSource<Tuple2<Integer,String>> dataSource = exeEnv.fromCollection(list).setParallelism(4);
        //dataSource.first(3).print();
        dataSource.groupBy(0).sortGroup(//TODO keySelector搞不出来
                0
                , Order.DESCENDING).first(2).print();
    }

    @Test
    public  void test5_env() throws Exception {
        ExecutionEnvironment exeEnv = ExecutionEnvironment.getExecutionEnvironment();
        myFlatMapFunction(exeEnv);
    }

    public void myFlatMapFunction(ExecutionEnvironment exeEnv) throws Exception {
        List<String> info = new ArrayList<>();
        info.add("hello,fuyiqi1");
        info.add("hello,fuyiqi2");
        info.add("hello,fuyiqi2");
        info.add("hello,fuyiqi3");
        info.add("hello,fuyiqi4");
        DataSource<String> dataSource = exeEnv.fromCollection(info);
        //dataSource.map((MapFunction<String, String[]>) value -> value.split(",")).print();
        dataSource.flatMap(
                new FlatMapFunction<String, String>() {
                    @Override
                    public void flatMap(String value, Collector<String> out) throws Exception {
                        for(String e:value.trim().split(",")){
                            out.collect(e);
                        }
                    }
                }
        ).map(
                new MapFunction<String, Tuple2<String,Integer>>() {
                    @Override
                    public Tuple2<String, Integer> map(String value) throws Exception {
                        return new Tuple2<String, Integer>(value,1);
                    }
                }
        ).groupBy(0).sum(1).print();

    }

    @Test
    public  void test6_env() throws Exception {
        ExecutionEnvironment exeEnv = ExecutionEnvironment.getExecutionEnvironment();
        myCrossFunction(exeEnv);
    }

    public void myCrossFunction(ExecutionEnvironment exeEnv) throws Exception {
        List info1 = new ArrayList();
        info1.add("hi1");
        info1.add("hi2");

        List info2 = new ArrayList();
        info2.add("gi1");
        info2.add("gi2");

        DataSource<String> dataSource1 = exeEnv.fromCollection(info1);
        DataSource<String> dataSource2 = exeEnv.fromCollection(info2);

        dataSource1.cross(dataSource2).print();
    }





















}
