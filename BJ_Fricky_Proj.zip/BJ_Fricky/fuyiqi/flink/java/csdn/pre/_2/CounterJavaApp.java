package csdn.pre._2;

import org.apache.flink.api.common.JobExecutionResult;
import org.apache.flink.api.common.accumulators.LongCounter;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.java.DataSet;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.core.fs.FileSystem;
import org.testng.annotations.Test;

public class CounterJavaApp {
    @Test
    public void myTest1() throws Exception {
        ExecutionEnvironment exeEnv = ExecutionEnvironment.getExecutionEnvironment();
        DataSource<String> dataSource = exeEnv.fromElements("a","b","c","e","f","g","h");
        DataSet<String> info = dataSource.map(
                new RichMapFunction<String, String>() {
                    //step1 定义计数器
                    LongCounter counter = new LongCounter();
                    //step2 注册计数器
                    @Override
                    public void open(Configuration parameters) throws Exception{
                        super.open(parameters);
                        RuntimeContext context = getRuntimeContext();
                        context.addAccumulator("elementCounterJava",counter);
                    }
                    @Override
                    public String map(String value) throws Exception {
                        counter.add(1);
                        return value;
                    }
                }
        );

        String filePath = "target/result";
        info.writeAsText(filePath, FileSystem.WriteMode.OVERWRITE).setParallelism(2);
        JobExecutionResult jobExecutionResult = exeEnv.execute("CounterJavaApp");
        Long num = jobExecutionResult.getAccumulatorResult("elementCounterJava");
        System.out.println(num);
    }





}
