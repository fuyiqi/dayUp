package csdn.pre._2;


import org.apache.commons.io.FileUtils;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.java.DataSet;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.configuration.Configuration;

import org.testng.annotations.Test;

import java.io.File;
import java.util.List;

public class DistribuCacheJavaApp {
    @Test
    public void myTest1() throws Exception{
        ExecutionEnvironment exeEnv = ExecutionEnvironment.getExecutionEnvironment();
        String filePath = "target/classes/input/hello";
        exeEnv.registerCachedFile(filePath,"DC1");

        DataSource<String> dataSource = exeEnv.fromElements("a","b","c","e","f","g","h");
        DataSet<String> info = dataSource.map(
                new RichMapFunction<String, String>() {
                    @Override
                    public void open(Configuration parameters) throws Exception{
                        super.open(parameters);
                        RuntimeContext context = getRuntimeContext();
                        File dcFile = context.getDistributedCache().getFile("DC1");
                        List<String> fileContent =  FileUtils.readLines(dcFile);
                        for(String e:fileContent){
                            System.out.println(e);
                        }
                    }
                    @Override
                    public String map(String value) throws Exception {
                        return value;
                    }
                }
        );
        info.print();
    }



}
