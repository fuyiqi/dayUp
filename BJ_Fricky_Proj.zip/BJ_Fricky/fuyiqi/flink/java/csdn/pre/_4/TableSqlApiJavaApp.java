package csdn.pre._4;

import org.apache.flink.api.java.DataSet;
import org.apache.flink.api.java.ExecutionEnvironment;


import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.java.BatchTableEnvironment;
import org.apache.flink.types.Row;
import org.testng.annotations.Test;

public class TableSqlApiJavaApp {

    @Test
    public void batchTest1() throws Exception {
        ExecutionEnvironment exeEnv = ExecutionEnvironment.getExecutionEnvironment();
        BatchTableEnvironment batchTableEnv = BatchTableEnvironment.create(exeEnv);
        String filePath = "target/classes/data/sales.csv";
        DataSet<Sales> csvContent = exeEnv.readCsvFile(filePath)
                .ignoreFirstLine()
                .pojoType(
                        Sales.class,
                        "transId","customId","itemId","amountPaid"
                );

        Table tableSales = batchTableEnv.fromDataSet(csvContent);
        batchTableEnv.registerTable("sales",tableSales);
        Table resTable = batchTableEnv.sqlQuery("select customId, sum(amountPaid)money from sales group by customId");
        DataSet<Row> rowDataSet = batchTableEnv.toDataSet(resTable, Row.class);
        rowDataSet.print();
    }

    public static class Sales{
        private long transId;
        private long customId;
        private long itemId;
        private double amountPaid;

        public Sales(long transId, long customId, long itemId, double amountPaid) {
            this.transId = transId;
            this.customId = customId;
            this.itemId = itemId;
            this.amountPaid = amountPaid;
        }

        public Sales() {
        }

        public long getTransId() {
            return transId;
        }

        public void setTransId(long transId) {
            this.transId = transId;
        }

        public long getCustomId() {
            return customId;
        }

        public void setCustomId(long customId) {
            this.customId = customId;
        }

        public long getItemId() {
            return itemId;
        }

        public void setItemId(long itemId) {
            this.itemId = itemId;
        }

        public double getAmountPaid() {
            return amountPaid;
        }

        public void setAmountPaid(double amountPaid) {
            this.amountPaid = amountPaid;
        }

        @Override
        public String toString() {
            return "Sales{" +
                    "transId=" + transId +
                    ", customId=" + customId +
                    ", itemId=" + itemId +
                    ", amountPaid=" + amountPaid +
                    '}';
        }
    }




}
