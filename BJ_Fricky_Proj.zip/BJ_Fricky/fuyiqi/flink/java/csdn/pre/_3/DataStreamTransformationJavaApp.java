package csdn.pre._3;

import org.apache.flink.api.common.JobExecutionResult;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.streaming.api.collector.selector.OutputSelector;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SplitStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

public class DataStreamTransformationJavaApp {

    public static class CustomNonParallelSourceFunction implements SourceFunction<Long> {
        private long count = 1L;
        private volatile boolean isRunning = true;

        @Override
        public void run(SourceContext<Long> ctx) throws Exception {
            while (isRunning){
                ctx.collect(count);
                count++;
                Thread.sleep(1000);
            }
        }

        @Override
        public void cancel() {
            isRunning = false;
        }
    }



    @Test
    public void test1_env() throws Exception {
        StreamExecutionEnvironment exeEnv = StreamExecutionEnvironment.getExecutionEnvironment();
        myTest1(exeEnv);
        JobExecutionResult jobExecutionResult = exeEnv.execute("hh1");
    }

    public void myTest1(StreamExecutionEnvironment exeEnv){
        DataStream<Long> dataStream = exeEnv.addSource(new CustomNonParallelSourceFunction(),"TestSource1")
                .map(
                        new MapFunction<Long, Long>() {
                            @Override
                            public Long map(Long value) throws Exception {
                                return (value+1)/2;
                            }
                        }
                ).filter(
                        new FilterFunction<Long>() {
                            @Override
                            public boolean filter(Long value) throws Exception {
                                return (value%2==0);
                            }
                        }
                );
        dataStream.print().setParallelism(1);
    }


    @Test
    public void test2_env() throws Exception {
        StreamExecutionEnvironment exeEnv = StreamExecutionEnvironment.getExecutionEnvironment();
        mySplitSelectFunction(exeEnv);
        JobExecutionResult jobExecutionResult = exeEnv.execute("hh2");
    }

    public void mySplitSelectFunction(StreamExecutionEnvironment exeEnv){
        DataStream<Long> dataStream = exeEnv.addSource(new CustomNonParallelSourceFunction(),"source2");
        SplitStream<Long> splitStream = dataStream.split(
                new OutputSelector<Long>(){
                    @Override
                    public Iterable<String> select(Long value) {
                        List<String> list = new ArrayList<>();
                        if(value%2==0){
                            list.add("odd");
                        }else {
                            list.add("even");
                        }
                        return list;
                    }
                }
        );
        splitStream.select("even").print().setParallelism(1);


    }















































































































































}
