package csdn.pre._3;

import org.apache.flink.api.common.JobExecutionResult;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.ParallelSourceFunction;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.testng.annotations.Test;

public class DataStreamDataStreamSourceJavaApp {

    @Test
    public void test1_env() throws Exception {
        StreamExecutionEnvironment exeEnv = StreamExecutionEnvironment.getExecutionEnvironment();
        mySocketFuntion(exeEnv);
        JobExecutionResult jobExecutionResult = exeEnv.execute("test1");
    }

    public void mySocketFuntion(StreamExecutionEnvironment exeEnv){
        DataStreamSource<String> dataStreamSource = exeEnv.socketTextStream("localhost",9000);
        dataStreamSource.print().setParallelism(1);
    }

    @Test
    public void test2_env() throws Exception {
        StreamExecutionEnvironment exeEnv = StreamExecutionEnvironment.getExecutionEnvironment();
        myNonParallelSourceFunction(exeEnv);
        JobExecutionResult jobExecutionResult = exeEnv.execute("mySourceFunction");
    }

    public static class CustomNonParallelSourceFunction implements SourceFunction<Long> {
        private long count = 1L;
        private volatile boolean isRunning = true;

        @Override
        public void run(SourceContext<Long> ctx) throws Exception {
            while (isRunning){
                ctx.collect(count);
                count++;
                Thread.sleep(1000);
            }
        }

        @Override
        public void cancel() {
            isRunning = false;
        }
    }

    public void myNonParallelSourceFunction(StreamExecutionEnvironment exeEnv){
        DataStreamSource<Long> dataStreamSource = exeEnv.addSource(
                new CustomNonParallelSourceFunction(),"myNonParallelSource"
        ).setParallelism(1);
        dataStreamSource.print().setParallelism(1);
    }

    @Test
    public void test3_env() throws Exception {
        StreamExecutionEnvironment exeEnv = StreamExecutionEnvironment.getExecutionEnvironment();
        myParallelSourceFunction(exeEnv);
        JobExecutionResult jobExecutionResult = exeEnv.execute("myParallelSource");
    }

    public static class CustomParallelSourceFunction implements ParallelSourceFunction<Long>{
        private long count = 0L;
        private volatile boolean isRunning = true;

        @Override
        public void run(SourceContext<Long> ctx) throws Exception {
            while (isRunning){
                ctx.collect(count);
                count++;
                Thread.sleep(1000);
            }
        }

        @Override
        public void cancel() {
            isRunning = false;
        }
    }

    public void myParallelSourceFunction(StreamExecutionEnvironment exeEnv){
        DataStreamSource<Long> dataStreamSource = exeEnv.addSource(
                new CustomParallelSourceFunction(),"myParallelSource"
        ).setParallelism(2);
        dataStreamSource.print().setParallelism(2);
    }


    @Test
    public void test4_env() throws Exception {
        StreamExecutionEnvironment exeEnv = StreamExecutionEnvironment.getExecutionEnvironment();
        myRichParallelSourceFunction(exeEnv);
        JobExecutionResult jobExecutionResult = exeEnv.execute("myRichParallelSource");
    }

    public void myRichParallelSourceFunction(StreamExecutionEnvironment exeEnv){
        DataStreamSource<Long> dataStreamSource = exeEnv.addSource(
                new CustomRichParallelSourceFunction(),"myRichParallelSource"
        ).setParallelism(2);
        dataStreamSource.print().setParallelism(2);
    }


    public static class CustomRichParallelSourceFunction extends RichParallelSourceFunction<Long> {
        private long count = 0L;
        private volatile boolean isRunning = true;
        @Override
        public void run(SourceContext<Long> ctx) throws Exception {
            while (isRunning){
                ctx.collect(count);
                count++;
                Thread.sleep(1000);
            }
        }

        @Override
        public void cancel() {
            isRunning = false;
        }

    }



































































































































}
