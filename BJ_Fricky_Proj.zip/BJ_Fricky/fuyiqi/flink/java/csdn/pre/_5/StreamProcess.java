package csdn.pre._5;

import org.apache.flink.api.common.functions.FilterFunction;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.ParallelSourceFunction;

import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.util.Collector;
import org.testng.annotations.Test;
import csdn.bean.Alert;

public class StreamProcess {

    @Test
    public void test1_env() throws Exception {
        StreamExecutionEnvironment exeEnv = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<Alert> alertStream = exeEnv.addSource(new AlertParallelSourceFunction()).setParallelism(8);
        alertStream.filter(
                new FilterFunction<Alert>() {
                    @Override
                    public boolean filter(Alert value) throws Exception {
                        return  value.getAppSys().contains("集中监控平台");
                    }
                }
        ).flatMap(
                new FlatMapFunction<Alert, Tuple2<Integer, Alert>>() {
                    @Override
                    public void flatMap(Alert value, Collector<Tuple2<Integer, Alert>> out) throws Exception {
                        out.collect(new Tuple2<>(1,value));
                    }
                }
        ).keyBy(
                new KeySelector<Tuple2<Integer, Alert>, String>() {
                    @Override
                    public String getKey(Tuple2<Integer, Alert> value) throws Exception {
                        return value.f1.getTitle();
                    }
                }
        ).timeWindow(Time.seconds(5)).sum(0)



                .print().setParallelism(1);
        exeEnv.execute("h1");
    }

    public static class AlertParallelSourceFunction implements ParallelSourceFunction<Alert> {
        private static Alert alertBase = new Alert();//需要序列化
        private volatile boolean isRunning = true;

        @Override
        public void run(SourceContext<Alert> ctx) throws Exception {
            while (isRunning){
                synchronized (ctx.getCheckpointLock()){
                    ctx.collect(alertBase.randomAlert());
                    //Thread.sleep(1000);
                }
            }
        }

        @Override
        public void cancel() {
            isRunning = false;
        }


    }


























}
