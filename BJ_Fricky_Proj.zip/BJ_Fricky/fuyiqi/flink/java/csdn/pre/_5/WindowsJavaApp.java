package csdn.pre._5;

import org.apache.commons.lang.StringUtils;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.util.Collector;
import org.testng.annotations.Test;

public class WindowsJavaApp {

    @Test
    public void test1() throws Exception {
        StreamExecutionEnvironment exeEnv = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> content = exeEnv.socketTextStream("localhost",9000);
        content.flatMap(
                new FlatMapFunction<String, Tuple2<String,Integer>>() {
                    @Override
                    public void flatMap(String value, Collector<Tuple2<String, Integer>> out) throws Exception {
                        String[] tokens = value.toLowerCase().split(" |\t|,|:|;|\\.|\\?|!|\"");
                        for (String token : tokens) {
                            if (StringUtils.isNotBlank(token)) {
                                out.collect(new Tuple2<String, Integer>(token, 1));
                            }
                        }
                    }
                }
        ).keyBy(0).timeWindow(Time.seconds(5),Time.seconds(2)).sum(1).print();//Slicing windows

        exeEnv.execute("hh");







    }












































}
