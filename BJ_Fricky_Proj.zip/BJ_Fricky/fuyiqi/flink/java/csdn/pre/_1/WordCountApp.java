package csdn.pre._1;

import org.apache.commons.lang.StringUtils;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.api.java.ExecutionEnvironment;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.operators.DataSource;
import org.apache.flink.api.java.tuple.Tuple2;

import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.util.Collector;
import org.testng.annotations.Test;


public class WordCountApp {


    @Test
    public void testBach() throws Exception {
        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
        String filePath = "target/classes/input/hello";
        DataSource<String> content = env.readTextFile(filePath);
        content.flatMap(
                new FlatMapFunction<String, Tuple2<String,Integer>>() {
                    public void flatMap(String value, Collector<Tuple2<String,Integer>> out)throws Exception{
                        String[] tokens = value.toLowerCase().split(" |\t|,|:|;|\\.|\\?|!");
                        for (String token:tokens){
                            if(StringUtils.isNotBlank(token)){
                                out.collect(new Tuple2<String,Integer>(token,1));
                            }
                        }
                    }
                }
        ).groupBy(0).sum(1).print();
    }

    /***************************************************************/

    @Test
    public void testStreaming() throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> content = env.socketTextStream("localhost",9000);
        content.flatMap(
                new FlatMapFunction<String, Tuple2<String,Integer>>() {
                    public void flatMap(String value, Collector<Tuple2<String,Integer>> out)throws Exception{
                        String[] tokens = value.toLowerCase().split(" |\t|,|:|;|\\.|\\?|!|\"");
                        for (String token:tokens){
                            if(StringUtils.isNotBlank(token)){
                                out.collect(new Tuple2<String,Integer>(token,1));
                            }
                        }
                    }
                }
        ).keyBy(0).timeWindow(Time.seconds(5)).sum(1).print().setParallelism(1);

        env.execute("Streaming");
    }

    @Test
    public void test2_Streaming() throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> content = env.socketTextStream("localhost",9000);
        content.flatMap(
                new FlatMapFunction<String, WC>() {
                    @Override
                    public void flatMap(String value, Collector<WC> out) throws Exception {
                        String[] tokens = value.toLowerCase().split(" |\t|,|:|;|\\.|\\?|!");
                        for (String token:tokens){
                            if(StringUtils.isNotBlank(token)){
                                out.collect(new WC(token,1));
                            }
                        }
                    }
                }
        ).keyBy("wordKey")
                .timeWindow(Time.seconds(5))
                .sum("count")
                .print().setParallelism(1);;

        env.execute("Streaming2");

    }

    @Test
    public void test3_Streaming() throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> content = env.socketTextStream("localhost",9000);
        content.flatMap(
                new FlatMapFunction<String, WC>() {
                    @Override
                    public void flatMap(String value, Collector<WC> out) throws Exception {
                        String[] tokens = value.toLowerCase().split(" |\t|,|:|;|\\.|\\?|!");
                        for (String token:tokens){
                            if(StringUtils.isNotBlank(token)){
                                out.collect(new WC(token.trim(),1));
                            }
                        }
                    }
                }
        ).keyBy(//使用keySelector
                new KeySelector<WC, String>() {
                    @Override
                    public String getKey(WC value) throws Exception {
                        return value.getWordKey();
                    }
                }
        )
                .timeWindow(Time.seconds(5))
                .sum("count")
                .print().setParallelism(1);;

        env.execute("Streaming3");

    }


    public static class WC {
        public String wordKey;
        public Integer count;

        public WC(){ }
        public WC(String wordKey,Integer count){
            this.count=count;
            this.wordKey=wordKey;
        }

        public String getWordKey() {
            return wordKey;
        }

        public void setWordKey(String wordKey) {
            this.wordKey = wordKey;
        }

        public Integer getCount() {
            return count;
        }

        public void setCount(Integer count) {
            this.count = count;
        }

        public String toString(){
            String str = "";
            str = String.format("WC={wordKey=%s,count=%d}",wordKey,count);
            return str;
        }


    }


    @Test
    public void test4_Streaming() throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> content = env.socketTextStream("localhost",9000);
        content.flatMap(
                new MyFlatMapFunction()
        ).keyBy(//使用keySelector
                new KeySelector<WC, String>() {
                    @Override
                    public String getKey(WC value) throws Exception {
                        return value.getWordKey();
                    }
                }
        )
                .timeWindow(Time.seconds(5))
                .sum("count")
                .print().setParallelism(1);;

        env.execute("Streaming4");

    }

    public static class MyFlatMapFunction implements FlatMapFunction<String,WC>{
        @Override
        public void flatMap(String value, Collector<WC> out) throws Exception {
            String[] tokens = value.toLowerCase().split(" |\t|,|:|;|\\.|\\?|!");
            for (String token:tokens){
                if(StringUtils.isNotBlank(token)){
                    out.collect(new WC(token.trim(),1));
                }
            }
        }
    }

    @Test
    public void test5_Streaming() throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> content = env.socketTextStream("localhost",9000);
        content.flatMap(
                new RichFlatMapFunction<String,WC>(){
                    @Override
                    public void flatMap(String value, Collector<WC> out) throws Exception {
                        String[] tokens = value.toLowerCase().split(" |\t|,|:|;|\\.|\\?|!");
                        for (String token:tokens){
                            if(StringUtils.isNotBlank(token)){
                                out.collect(new WC(token.trim(),1));
                            }
                        }
                    }
                }
        ).keyBy(//使用keySelector
                new KeySelector<WC, String>() {
                    @Override
                    public String getKey(WC value) throws Exception {
                        return value.getWordKey();
                    }
                }
        )
                .timeWindow(Time.seconds(5))
                .sum("count")
                .print().setParallelism(1);;

        env.execute("Streaming5");

    }






}
