package utils;

import java.util.Random;

public class DBUtil {



    public static String getConnection(){
        return "connenction="+new Random().nextInt(10);
    }

    public void returnConnection(String connenction){}



}
