package utils;

import org.apache.flink.configuration.ConfigConstants;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class MyJavaStreamExecutionLocalEnvironment {

    public static final StreamExecutionEnvironment getInstance(){
        //创建本地运行带web
        Configuration conf = new Configuration();
        conf.setBoolean(ConfigConstants.LOCAL_START_WEBSERVER, true);
        return StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
    }



}
